package fathmah_aritmatika;

public class luas_lingkaran {

    public static void main(String[] args) {
        
    int r = 14;
    int phi = 22/7;
    double Luas = phi * (r * r) ;
    
    System.out.println("jari-jari = " + (r));
    System.out.println("Luas Lingkaran = " + (Luas));
    
    }

}
