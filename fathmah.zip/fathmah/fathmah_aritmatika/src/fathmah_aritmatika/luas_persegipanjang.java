package fathmah_aritmatika;

public class luas_persegipanjang {
    
    public static void main(String[] args) {
        
    int p = 30;
    int l = 15;
    int t = 10;
    double Luas = p * l * t ;
    
    System.out.println("panjang = " + (p));
    System.out.println("panjang = " + (l));
    System.out.println("panjang = " + (t));
    System.out.println("Luas Persegi panjang = " + (Luas));
    
    }
 
}
